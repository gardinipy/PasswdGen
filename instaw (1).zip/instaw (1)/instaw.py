import os
import time
import colorama
from colorama import Fore, init
import pyfiglet

init(autoreset=True)

try:
    from lolpython import lol_py 
    import pyfiglet
except ImportError:
    os.system("pip install lolpython")
    os.system("pip install pyfiglet")

n = Fore.RESET
r = Fore.RED
lg = Fore.GREEN
rs = Fore.RESET
w = Fore.WHITE
cy = Fore.CYAN
ye = Fore.YELLOW

def banner():
    os.system("clear")
    result = pyfiglet.figlet_format("    Instaw ", font="slant")
    lol_py(result) 
    lol_py('                                 Version: 1.0\n')

def getaccinfo():
    USERNAME = input(f'{INPUT}{cy} Enter Account Username: {r}')
    PASSWORD = input(f'{INPUT}{cy} Enter Account Password: {r}')
    os.system(f'python2 main.py -u {USERNAME} -p {PASSWORD} -o info')

# Resto do código...

def main_menu():
    banner()
    print(f'{re}[1] Instagram Account Info:'+n)
    print(f'{gr}[2] Follow Instagram Account by Tag:'+n)
    print(f'{cy}[3] Follow Instagram Account by Location:'+n)
    print(f'{re}[4] FollowBack All Followers:'+n)
    print(f'{gr}[5] Follow Users from Lists:'+n)
    print(f'{cy}[6] UnfollowBack All Users:'+n)
    print(f'{re}[7] Unfollow All Users:'+n)
    print(f'{gr}[8] Setup Script:'+n)
    print(f'{cy}[9] Increase Followers:'+n)
    print(f'{gr}[10] Exit:'+n)
    
    a = int(input('\nEnter your choice: '))
    if a == 1:
        getaccinfo()
    elif a == 2:
        followbytag()
    elif a == 3:
        followbylocation()
    elif a == 4:
        followback()
    elif a == 5:
        followusersfromlist()
    elif a == 6:
        unfollowback()
    elif a == 7:
        unfollowallusers()
    elif a == 8:
        setup()
    elif a == 9:
        followusersfromlists()
    elif a == 10:
        quit()

main_menu()
